import Route from '@ember/routing/route';

export default class CustomersListRoute extends Route {}
