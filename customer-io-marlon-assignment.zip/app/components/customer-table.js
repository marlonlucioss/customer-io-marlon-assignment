import Component from '@glimmer/component';

export default class CounterComponent extends Component {}
